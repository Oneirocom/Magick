declare const InputGenerator: ({ updateData, control, initialValue }: {
    updateData: any;
    control: any;
    initialValue: any;
}) => JSX.Element;
export default InputGenerator;
