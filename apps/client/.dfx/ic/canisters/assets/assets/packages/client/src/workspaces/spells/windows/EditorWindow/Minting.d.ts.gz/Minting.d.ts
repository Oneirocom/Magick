declare const MintingView: ({ open, setOpen, spellId, close }: {
    open: any;
    setOpen: any;
    spellId: any;
    close: any;
}) => JSX.Element;
export default MintingView;
