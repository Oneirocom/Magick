declare const DeploymentView: ({ open, setOpen, spellId, close }: {
    open: any;
    setOpen: any;
    spellId: any;
    close: any;
}) => JSX.Element;
export default DeploymentView;
