interface FeathersContext {
    client: any | null;
}
export declare const useFeathers: () => FeathersContext;
declare const ConditionalProvider: (props: any) => any;
export default ConditionalProvider;
