declare const DocumentEditModal: ({ closeModal, field, document, getDocuments }: {
    closeModal: any;
    field: any;
    document: any;
    getDocuments: any;
}) => JSX.Element;
export default DocumentEditModal;
