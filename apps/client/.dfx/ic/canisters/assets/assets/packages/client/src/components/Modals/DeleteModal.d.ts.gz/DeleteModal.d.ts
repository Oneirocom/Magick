declare const DeleteModal: ({ closeModal, handledelete, id }: {
    closeModal: any;
    handledelete: any;
    id: any;
}) => JSX.Element;
export default DeleteModal;
