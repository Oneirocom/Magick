declare const ModuleSelect: ({ control, updateData, initialValue }: {
    control: any;
    updateData: any;
    initialValue: any;
}) => JSX.Element;
export default ModuleSelect;
