declare const StoreAddEditModal: ({ closeModal, store, getDocumentsStores, opType }: {
    closeModal: any;
    store: any;
    getDocumentsStores: any;
    opType: any;
}) => JSX.Element;
export default StoreAddEditModal;
