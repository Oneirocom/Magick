declare const OpenProject: ({ spells, setSelectedSpell, selectedSpell, loadFile, openSpell, }: {
    spells: any;
    setSelectedSpell: any;
    selectedSpell: any;
    loadFile: any;
    openSpell: any;
}) => JSX.Element;
export default OpenProject;
