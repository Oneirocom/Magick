declare const ContentObjEditModal: ({ contents, getContentObjects }: {
    contents: any;
    getContentObjects: any;
}) => JSX.Element;
export default ContentObjEditModal;
