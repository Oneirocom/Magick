export declare const getItem: (key: string) => any;
export declare const setItem: (key: string, value: string) => void;
export declare const removeItem: (item: string) => void;
export declare const clearStorage: () => void;
