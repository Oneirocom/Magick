/// <reference types="react" />
import 'flexlayout-react/style/dark.css';
import './design-globals/design-globals.css';
import './App.css';
declare function App(): JSX.Element;
export default App;
