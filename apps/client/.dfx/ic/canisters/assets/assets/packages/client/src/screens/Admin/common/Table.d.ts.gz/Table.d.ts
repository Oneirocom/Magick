declare const TableIndex: ({ column, data, handledelete, modal, handleChangePage, page, loading, }: {
    column: any;
    data: any;
    handledelete: any;
    modal: any;
    handleChangePage: any;
    page: any;
    loading: any;
}) => JSX.Element;
export default TableIndex;
