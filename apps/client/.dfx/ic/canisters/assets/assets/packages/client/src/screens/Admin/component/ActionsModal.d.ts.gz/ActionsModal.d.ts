/// <reference types="react" />
export default function ActionModal({ anchorEl, open, handleClose, handledelete, id, modal, }: {
    anchorEl: any;
    open: any;
    handleClose: any;
    handledelete: any;
    id: any;
    modal: any;
}): JSX.Element;
