export declare const getEnkiPrompt: (taskName: any) => Promise<any>;
export declare const getEnkis: () => Promise<any>;
export declare const postEnkiCompletion: (taskName: any, inputs: any) => Promise<any>;
