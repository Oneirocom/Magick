declare const ContentObject: ({ content, getContentObjects }: {
    content: any;
    getContentObjects: any;
}) => JSX.Element;
export default ContentObject;
