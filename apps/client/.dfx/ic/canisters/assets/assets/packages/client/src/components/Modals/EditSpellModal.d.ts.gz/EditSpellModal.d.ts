declare const EditSpellModal: ({ closeModal, spellId, name, tab }: {
    closeModal: any;
    spellId: any;
    name: any;
    tab: any;
}) => JSX.Element;
export default EditSpellModal;
