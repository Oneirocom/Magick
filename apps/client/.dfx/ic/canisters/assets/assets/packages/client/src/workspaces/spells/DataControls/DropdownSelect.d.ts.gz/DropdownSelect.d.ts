declare const DropdownSelect: ({ control, updateData, initialValue }: {
    control: any;
    updateData: any;
    initialValue: any;
}) => JSX.Element | undefined;
export default DropdownSelect;
