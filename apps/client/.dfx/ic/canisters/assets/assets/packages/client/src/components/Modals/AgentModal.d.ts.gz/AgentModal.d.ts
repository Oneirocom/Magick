/// <reference types="react" />
declare const AgentModal: ({ content, onClose, options: _options }: {
    content: any;
    onClose: any;
    options: any;
}) => JSX.Element;
export default AgentModal;
