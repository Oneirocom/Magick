export declare const columnClientSetting: {
    id: string;
    name: string;
}[];
export declare const columnConfig: {
    id: string;
    name: string;
}[];
export declare const columnScope: {
    id: string;
    name: string;
}[];
