declare const DocumentAddModal: ({ closeModal, storeId, documentId, isContentObject, getDocuments, getContentObjects, }: {
    closeModal: any;
    storeId: any;
    documentId: any;
    isContentObject: any;
    getDocuments: any;
    getContentObjects: any;
}) => JSX.Element;
export default DocumentAddModal;
