declare const StoreDeleteModal: ({ closeModal, store, getDocumentsStores }: {
    closeModal: any;
    store: any;
    getDocumentsStores: any;
}) => JSX.Element;
export default StoreDeleteModal;
