declare const DocumentDeleteModal: ({ closeModal, documentId, objId, isContentObj, getDocuments, getContentObjects, }: {
    closeModal: any;
    documentId: any;
    objId: any;
    isContentObj: any;
    getDocuments: any;
    getContentObjects: any;
}) => JSX.Element;
export default DocumentDeleteModal;
